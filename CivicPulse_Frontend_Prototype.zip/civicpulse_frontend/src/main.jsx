import React, { useMemo, useState } from "react";
import { createRoot } from "react-dom/client";
import {
  Activity, AlertCircle, ArrowRight, BarChart3, Bell, Camera, CheckCircle2,
  ChevronDown, ClipboardList, Clock3, FileText, Filter, Globe2, Home,
  ImagePlus, MapPin, Menu, Mic, Search, Shield, ShieldCheck, Siren,
  Sparkles, Upload, Users, Vote, X, Zap
} from "lucide-react";
import "./styles.css";

const initialIssues = [
  { id: "CP-2026-1042", title: "Overflowing garbage near MVP Colony", category: "Garbage", ward: "Ward 12", status: "In Progress", date: "05 Nov 2026", priority: "High", location: "MVP Colony, Sector 5", description: "Waste has not been collected for several days and is spreading near the junction.", citizen: "Resident", image: "https://images.unsplash.com/photo-1532996122724-e3c354a0b15b?w=900&q=80" },
  { id: "CP-2026-1038", title: "Streetlight not working", category: "Streetlight", ward: "Ward 8", status: "Assigned", date: "04 Nov 2026", priority: "Medium", location: "Seethammadhara Main Road", description: "The streetlight at the bus stop is not working after sunset.", citizen: "Resident", image: "https://images.unsplash.com/photo-1519501025264-65ba15a82390?w=900&q=80" },
  { id: "CP-2026-1029", title: "Water leakage from pipeline", category: "Water", ward: "Ward 4", status: "Resolved", date: "02 Nov 2026", priority: "High", location: "Madhurawada, near market", description: "Water is leaking from a roadside pipeline.", citizen: "Resident", image: "https://images.unsplash.com/photo-1548337138-e87d889cc369?w=900&q=80" }
];

function App() {
  const [portal, setPortal] = useState("home");
  const [citizenTab, setCitizenTab] = useState("report");
  const [adminTab, setAdminTab] = useState("dashboard");
  const [workerTab, setWorkerTab] = useState("task");
  const [issues, setIssues] = useState(initialIssues);
  const [selected, setSelected] = useState(initialIssues[0]);
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState("All");
  const [trackingId, setTrackingId] = useState("");
  const [notice, setNotice] = useState("");
  const [report, setReport] = useState({ title: "", category: "Road", location: "", description: "" });
  const [photo, setPhoto] = useState(null);
  const [workerId, setWorkerId] = useState("");
  const [repairPhoto, setRepairPhoto] = useState(null);
  const [repairNote, setRepairNote] = useState("");
  const [statusNote, setStatusNote] = useState("");
  const [mobileNav, setMobileNav] = useState(false);

  const filteredIssues = useMemo(() => issues.filter(i =>
    (filter === "All" || i.status === filter) &&
    `${i.id} ${i.title} ${i.location} ${i.category}`.toLowerCase().includes(search.toLowerCase())
  ), [issues, filter, search]);

  function goHome() { setPortal("home"); setNotice(""); }
  function createComplaint(e) {
    e.preventDefault();
    if (!photo) { setNotice("Please capture or select a photo for this demo submission."); return; }
    const id = `CP-2026-${Math.floor(1100 + Math.random() * 800)}`;
    const item = {
      id, title: report.title || `${report.category} issue`, category: report.category,
      ward: "Ward to be identified", status: "Pending", date: new Date().toLocaleDateString("en-IN"),
      priority: "Under review", location: report.location || "Location pending",
      description: report.description, citizen: "You", image: photo
    };
    setIssues(prev => [item, ...prev]);
    setSelected(item);
    setTrackingId(id);
    setNotice(`Complaint submitted successfully. Your Tracking ID is ${id}`);
    setReport({ title: "", category: "Road", location: "", description: "" });
    setPhoto(null);
    setCitizenTab("track");
  }
  function updateIssue(id, patch) {
    setIssues(prev => prev.map(i => i.id === id ? { ...i, ...patch } : i));
    setSelected(prev => prev.id === id ? { ...prev, ...patch } : prev);
  }
  function handleImage(e, setter) {
    const f = e.target.files?.[0];
    if (f) setter(URL.createObjectURL(f));
  }
  function issueCard(i) {
    return <button className="issue-row" key={i.id} onClick={() => setSelected(i)}>
      <div className="issue-thumb"><img src={i.image} alt="" /></div>
      <div className="issue-copy"><b>{i.title}</b><span>{i.id} · {i.location}</span></div>
      <Status value={i.status} />
      <ArrowRight size={16} />
    </button>;
  }

  if (portal === "home") return <Landing onEnter={setPortal} />;
  return <div className="app-shell">
    <header className="topbar">
      <button className="brand" onClick={goHome}><span className="brand-mark"><Activity size={19}/></span><span><b>CivicPulse</b><small>Municipal Network Active</small></span></button>
      <div className="top-links"><span>Overview</span><span>Governance</span><span>Public Issues</span><span>Transparency</span></div>
      <div className="top-right"><span className="live-dot"/> Demo workspace <button className="icon-button" onClick={goHome}><Home size={17}/></button><button className="menu-toggle" onClick={() => setMobileNav(!mobileNav)}><Menu/></button></div>
    </header>
    <div className="workspace">
      <aside className={`sidebar ${mobileNav ? "open" : ""}`}>
        <div className="side-label">{portal === "citizen" ? "CITIZEN PORTAL" : portal === "worker" ? "WORKER PORTAL" : "ADMINISTRATION"}</div>
        {portal === "citizen" && <>
          <Nav active={citizenTab==="report"} icon={<FileText/>} label="Report an Issue" onClick={()=>setCitizenTab("report")}/>
          <Nav active={citizenTab==="nearby"} icon={<MapPin/>} label="Nearby Issues" onClick={()=>setCitizenTab("nearby")}/>
          <Nav active={citizenTab==="track"} icon={<ClipboardList/>} label="Track Complaints" onClick={()=>setCitizenTab("track")}/>
        </>}
        {portal === "worker" && <>
          <Nav active={workerTab==="task"} icon={<ClipboardList/>} label="Assigned Complaint" onClick={()=>setWorkerTab("task")}/>
          <Nav active={workerTab==="evidence"} icon={<Camera/>} label="Submit Repair Evidence" onClick={()=>setWorkerTab("evidence")}/>
        </>}
        {portal === "admin" && <>
          <Nav active={adminTab==="dashboard"} icon={<BarChart3/>} label="Dashboard" onClick={()=>setAdminTab("dashboard")}/>
          <Nav active={adminTab==="complaints"} icon={<ClipboardList/>} label="Complaint Management" onClick={()=>setAdminTab("complaints")}/>
          <Nav active={adminTab==="intelligence"} icon={<Activity/>} label="Civic Intelligence" onClick={()=>setAdminTab("intelligence")}/>
          <Nav active={adminTab==="resolution"} icon={<ShieldCheck/>} label="Resolution & Accountability" onClick={()=>setAdminTab("resolution")}/>
        </>}
        <div className="sidebar-bottom"><div className="secure-note"><ShieldCheck size={16}/><span>Role-based demo access<br/><b>Prototype mode</b></span></div><button className="nav-item" onClick={goHome}><ArrowRight className="back-icon"/> Back to landing page</button></div>
      </aside>
      <main className="main-content">
        {notice && <div className="notice"><CheckCircle2 size={17}/><span>{notice}</span><button onClick={()=>setNotice("")}><X size={16}/></button></div>}
        {portal === "citizen" && <>
          <PageHeading eyebrow="YOUR CITY. YOUR VOICE." title={citizenTab==="report"?"Report a civic issue":citizenTab==="nearby"?"Issues near your community":"Track your complaints"} subtitle={citizenTab==="report"?"Tell your municipality what needs attention. Your report helps make the city better.":citizenTab==="nearby"?"View reported issues and confirm problems in your neighbourhood.":"Follow every update from submission to resolution."}/>
          <div className="tabs">
            <Tab active={citizenTab==="report"} onClick={()=>setCitizenTab("report")}>Report an Issue</Tab>
            <Tab active={citizenTab==="nearby"} onClick={()=>setCitizenTab("nearby")}>Nearby Issues</Tab>
            <Tab active={citizenTab==="track"} onClick={()=>setCitizenTab("track")}>Track Complaints</Tab>
          </div>
          {citizenTab==="report" && <div className="grid-two">
            <section className="panel"><div className="panel-head"><div><h2>Submit a new complaint</h2><p>Fields marked required must be completed.</p></div><span className="step-chip">01 / REPORT</span></div>
              <form onSubmit={createComplaint} className="form">
                <label>Issue title<input required value={report.title} onChange={e=>setReport({...report,title:e.target.value})} placeholder="e.g. Pothole near school entrance"/></label>
                <div className="form-row"><label>Category<select value={report.category} onChange={e=>setReport({...report,category:e.target.value})}><option>Road</option><option>Garbage</option><option>Water</option><option>Drainage</option><option>Streetlight</option><option>Other</option></select></label><label>Location<input value={report.location} onChange={e=>setReport({...report,location:e.target.value})} placeholder="Area / landmark"/></label></div>
                <label>Description<textarea rows="4" value={report.description} onChange={e=>setReport({...report,description:e.target.value})} placeholder="Describe the issue briefly..."/></label>
                <div className="capture-box"><div className="capture-icon"><Camera/></div><div className="capture-text"><b>Issue photo <em>Required</em></b><span>Attach a clear photo of the civic issue.</span></div><label className="outline-btn"><ImagePlus size={15}/> Add photo<input type="file" accept="image/*" capture="environment" onChange={e=>handleImage(e,setPhoto)} hidden/></label></div>
                {photo && <div className="photo-preview"><img src={photo} alt="Issue preview"/><span>Photo attached</span><button type="button" onClick={()=>setPhoto(null)}>Remove</button></div>}
                <div className="capture-box optional"><div className="capture-icon"><Mic/></div><div className="capture-text"><b>Voice description <small>Optional</small></b><span>Live voice recording can be connected in the next development step.</span></div><button type="button" className="outline-btn" onClick={()=>setNotice("Microphone recording will be connected in the next development step.")}><Mic size={15}/> Record</button></div>
                <div className="capture-box optional"><div className="capture-icon"><MapPin/></div><div className="capture-text"><b>Location capture <small>Optional in demo</small></b><span>GPS permission and live location will be connected later.</span></div><button type="button" className="outline-btn" onClick={()=>setNotice("GPS capture will be connected in the next development step.")}><MapPin size={15}/> Get location</button></div>
                <button className="primary-btn wide" type="submit">Submit complaint <ArrowRight size={16}/></button>
              </form>
            </section>
            <section className="panel side-panel"><div className="panel-head"><div><h2>What happens next?</h2><p>Your complaint follows a transparent process.</p></div><Sparkles color="#368e91"/></div>
              <div className="timeline"><TimelineItem n="01" title="Complaint received" desc="Your report is saved and a unique Tracking ID is generated."/><TimelineItem n="02" title="AI-assisted review" desc="The issue is categorised and checked for similar reports."/><TimelineItem n="03" title="Assigned to department" desc="Municipal staff review and assign the issue to a team."/><TimelineItem n="04" title="Work & verification" desc="Repair evidence is reviewed before the complaint is closed."/></div>
              <div className="info-card"><ShieldCheck size={18}/><span><b>Transparent by design</b><br/>You can track the status and see resolution evidence when available.</span></div>
            </section>
          </div>}
          {citizenTab==="nearby" && <div className="grid-two list-layout"><section className="panel"><div className="toolbar"><h2>Reported in your area</h2><span className="muted">Sample community reports</span></div>{issues.map(issueCard)}</section><section className="panel"><h2>Issue details</h2><IssueDetails issue={selected}/><div className="map-placeholder"><MapPin size={26}/><b>{selected.location}</b><span>Map preview · connect Maps API later</span></div><button className="primary-btn wide" onClick={()=>setNotice(`You confirmed ${selected.id} as an existing issue.`)}> <CheckCircle2 size={16}/> Confirm this issue</button></section></div>}
          {citizenTab==="track" && <div className="grid-two list-layout"><section className="panel"><div className="toolbar"><h2>Your complaints</h2><span className="count-pill">{issues.filter(i=>i.citizen==="You").length} submitted by you</span></div><label className="search-box"><Search size={16}/><input placeholder="Enter a Tracking ID" value={trackingId} onChange={e=>setTrackingId(e.target.value)}/></label>{issues.filter(i=>i.citizen==="You").map(issueCard)}{!issues.some(i=>i.citizen==="You")&&<Empty text="Your submitted complaints will appear here. Submit a report to generate a Tracking ID."/>}</section><section className="panel"><h2>Complaint status</h2><IssueDetails issue={selected}/><div className="timeline compact"><TimelineItem n="✓" title="Submitted" desc={selected.date}/><TimelineItem n={selected.status==="Pending"?"02":"✓"} title="Assigned / In progress" desc={selected.status==="Pending"?"Awaiting department review":"Department update recorded"}/><TimelineItem n={selected.status==="Resolved"?"✓":"03"} title="Resolved" desc={selected.status==="Resolved"?"Resolution approved":"Pending final verification"}/></div>{selected.status==="Resolved"&&<button className="outline-btn" onClick={()=>setNotice("Reopen request submitted for admin review.")}>Not fixed? Reopen complaint</button>}</section></div>}
        </>}
        {portal === "worker" && <>
          <PageHeading eyebrow="FIELD OPERATIONS" title="Worker Portal" subtitle="View assigned civic issues and submit repair evidence for administrative review."/>
          <div className="tabs"><Tab active={workerTab==="task"} onClick={()=>setWorkerTab("task")}>Assigned Complaint</Tab><Tab active={workerTab==="evidence"} onClick={()=>setWorkerTab("evidence")}>Submit Repair Evidence</Tab></div>
          {workerTab==="task" && <div className="grid-two list-layout"><section className="panel"><h2>Find assigned complaint</h2><p className="muted">Enter the Tracking ID provided by your supervisor.</p><label className="search-box"><Search size={16}/><input value={workerId} onChange={e=>setWorkerId(e.target.value)} placeholder="e.g. CP-2026-1042"/></label><button className="primary-btn" onClick={()=>{const f=issues.find(i=>i.id.toLowerCase()===workerId.toLowerCase());if(f){setSelected(f);setNotice("Complaint loaded.");}else setNotice("No matching complaint found. Check the Tracking ID.");}}>Load complaint</button><div className="divider"/>{issues.map(issueCard)}</section><section className="panel"><h2>Assigned issue details</h2><IssueDetails issue={selected}/><img className="large-photo" src={selected.image} alt="Original issue"/><button className="primary-btn wide" onClick={()=>setWorkerTab("evidence")}>Submit repair evidence <ArrowRight size={16}/></button></section></div>}
          {workerTab==="evidence" && <div className="panel narrow-panel"><div className="panel-head"><div><h2>Submit repair evidence</h2><p>Evidence is sent to the administrator for review. Workers cannot approve their own work.</p></div><ShieldCheck color="#368e91"/></div><form className="form" onSubmit={e=>{e.preventDefault();if(!repairPhoto){setNotice("Please attach an after-repair photo.");return;}setNotice(`Repair evidence for ${selected.id} submitted for admin review.`);setRepairPhoto(null);setRepairNote("");}}><label>Complaint Tracking ID<input value={workerId} onChange={e=>setWorkerId(e.target.value)} placeholder={selected.id}/></label><div className="capture-box"><Camera/><div className="capture-text"><b>After-repair photo <em>Required</em></b><span>Capture a photo showing the completed repair.</span></div><label className="outline-btn"><Upload size={15}/> Add photo<input type="file" accept="image/*" capture="environment" hidden onChange={e=>handleImage(e,setRepairPhoto)}/></label></div>{repairPhoto&&<div className="photo-preview"><img src={repairPhoto} alt="Repair evidence"/><span>Evidence attached</span></div>}<label>Work completed / notes<textarea rows="4" value={repairNote} onChange={e=>setRepairNote(e.target.value)} placeholder="Describe the repair work carried out..."/></label><div className="info-card"><MapPin size={18}/><span><b>GPS and timestamp</b><br/>Live GPS and trusted server timestamp will be connected in the next phase.</span></div><button className="primary-btn wide">Submit evidence for admin review <ArrowRight size={16}/></button></form></div>}
        </>}
        {portal === "admin" && <>
          <PageHeading eyebrow="MUNICIPAL CONTROL CENTRE" title="Administration" subtitle="Review citizen reports, coordinate field response and ensure accountable resolution."/>
          <div className="tabs"><Tab active={adminTab==="dashboard"} onClick={()=>setAdminTab("dashboard")}>Dashboard</Tab><Tab active={adminTab==="complaints"} onClick={()=>setAdminTab("complaints")}>Complaint Management</Tab><Tab active={adminTab==="intelligence"} onClick={()=>setAdminTab("intelligence")}>Civic Intelligence</Tab><Tab active={adminTab==="resolution"} onClick={()=>setAdminTab("resolution")}>Resolution & Accountability</Tab></div>
          {adminTab==="dashboard" && <><div className="stats-grid"><Stat label="Total complaints" value={issues.length} icon={<ClipboardList/>}/><Stat label="Pending complaints" value={issues.filter(i=>i.status==="Pending").length} icon={<Clock3/>}/><Stat label="Resolved complaints" value={issues.filter(i=>i.status==="Resolved").length} icon={<CheckCircle2/>}/><Stat label="Urgent complaints" value={issues.filter(i=>i.priority==="High").length} icon={<Siren/>}/></div><div className="grid-two list-layout"><section className="panel"><div className="toolbar"><h2>Recent complaints</h2><button className="text-btn" onClick={()=>setAdminTab("complaints")}>View all <ArrowRight size={14}/></button></div>{issues.slice(0,5).map(issueCard)}</section><section className="panel"><h2>Municipal response overview</h2><div className="bar-chart">{["Roads","Garbage","Water","Drainage","Streetlights"].map((x,i)=><div className="bar-line" key={x}><span>{x}</span><div><i style={{width:[78,56,68,32,43][i]+"%"}}/></div><b>{[78,56,68,32,43][i]}%</b></div>)}</div><div className="info-card"><Activity size={18}/><span><b>Live civic intelligence</b><br/>Charts currently use sample values for the prototype.</span></div></section></div></>}
          {adminTab==="complaints" && <div className="panel"><div className="toolbar wrap"><div><h2>All complaints</h2><p className="muted">Review, assign and update complaint status.</p></div><label className="search-box small-search"><Search size={15}/><input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search complaints"/></label></div><div className="filter-row"><Filter size={15}/>{["All","Pending","Assigned","In Progress","Resolved","Reopened"].map(x=><button className={`filter-chip ${filter===x?"active":""}`} onClick={()=>setFilter(x)} key={x}>{x}</button>)}</div><div className="issue-list">{filteredIssues.map(issueCard)}</div><div className="divider"/><div className="grid-two admin-detail"><section><h3>Selected complaint</h3><IssueDetails issue={selected}/></section><section><h3>Administrative action</h3><label>Assign department<select defaultValue="Sanitation Department"><option>Roads Department</option><option>Sanitation Department</option><option>Water Supply Department</option><option>Electrical Department</option><option>Drainage Department</option></select></label><label>Update status<select value={selected.status} onChange={e=>updateIssue(selected.id,{status:e.target.value})}><option>Pending</option><option>Assigned</option><option>In Progress</option><option>Resolved</option><option>Reopened</option></select></label><label>Update note<textarea rows="3" value={statusNote} onChange={e=>setStatusNote(e.target.value)} placeholder="Add an administrative note..."/></label><button className="primary-btn" onClick={()=>setNotice(`Administrative update saved for ${selected.id}.`)}>Save update</button></section></div></div>}
          {adminTab==="intelligence" && <div className="grid-two list-layout"><section className="panel"><h2>Civic hotspots</h2><div className="map-placeholder tall"><MapPin size={30}/><b>Ward-level issue map</b><span>Map integration pending · sample hotspots</span><div className="hotspot-pills"><span>Ward 12 · 18 reports</span><span>Ward 8 · 11 reports</span><span>Ward 4 · 9 reports</span></div></div></section><section className="panel"><h2>Recurring issues</h2>{["Waste collection delays","Streetlights not working","Road surface damage","Water pipeline leakage"].map((x,i)=><div className="recurring-row"><span className="recurring-number">0{i+1}</span><b>{x}</b><span className="muted">{[18,11,9,7][i]} reports</span></div>)}<div className="divider"/><h2>Ward-wise statistics</h2><div className="bar-chart">{["Ward 12","Ward 8","Ward 4","Ward 2"].map((x,i)=><div className="bar-line"><span>{x}</span><div><i style={{width:[88,62,44,28][i]+"%"}}/></div><b>{[18,11,9,5][i]}</b></div>)}</div></section></div>}
          {adminTab==="resolution" && <div className="grid-two list-layout"><section className="panel"><h2>Evidence awaiting review</h2>{issues.filter(i=>i.status==="In Progress"||i.status==="Resolved").map(issueCard)}<div className="info-card"><ShieldCheck size={18}/><span><b>Human approval required</b><br/>AI can assist with evidence review, but an authorised administrator makes the final decision.</span></div></section><section className="panel"><h2>Resolution evidence</h2><IssueDetails issue={selected}/><div className="evidence-compare"><div><span>Before repair</span><img src={selected.image} alt="Before repair"/></div><div><span>After repair</span><div className="empty-image"><Camera/><small>Worker evidence will appear here</small></div></div></div><div className="toolbar"><button className="outline-btn" onClick={()=>setNotice("Evidence marked as needing further review.")}>Needs review</button><button className="primary-btn" onClick={()=>{updateIssue(selected.id,{status:"Resolved"});setNotice(`${selected.id} approved and marked Resolved.`);}}>Approve resolution</button></div></section></div>}
        </>}
      </main>
    </div>
    <footer className="footer"><b>CivicPulse</b><span>Public service, made accountable.</span><span>Prototype · Sample data only</span></footer>
  </div>;
}

function Landing({onEnter}) {
  return <div className="landing">
    <header className="topbar landing-top"><button className="brand"><span className="brand-mark"><Activity size={19}/></span><span><b>CivicPulse</b><small>Municipal Network Active</small></span></button><nav className="top-links"><a href="#overview">Overview</a><a href="#portals">Governance</a><a href="#portals">Public Issues</a><a href="#transparency">Transparency</a></nav><div className="top-right"><span>Sign in</span><Shield size={17}/></div></header>
    <section className="hero" id="overview"><div className="hero-tag"><span className="live-dot"/> PUBLIC CIVIC ENGINE · MUNICIPAL GATEWAY</div><div className="hero-logo"><Activity size={27}/></div><b className="hero-name">CivicPulse</b><h1>Your City. Your Voice. <span>Better Governance.</span></h1><p>CivicPulse connects residents and local government. Report civic issues, track public initiatives and build a more responsive, transparent city together.</p><div className="hero-metrics"><Metric value="24/7" label="Issue Reporting"/><Metric value="Live" label="Complaint Tracking"/><Metric value="3" label="Connected Portals"/><Metric value="100%" label="Transparent Workflow"/></div></section>
    <section className="portal-section" id="portals"><div className="section-kicker">♧ SELECT PORTAL ACCESS POINT</div><h2>Choose Your Civic Engagement Path</h2><div className="portal-grid">
      <PortalCard accent="teal" icon={<Users/>} label="Citizen Mode" badge="Public Resident Access" desc="Report local issues, view nearby complaints, track progress and confirm problems in your community." features={["Report Civic Issues","Nearby Community Issues","Track Complaint Status","Confirm Existing Issues"]} button="Enter Citizen Mode" onClick={()=>onEnter("citizen")}/>
      <PortalCard accent="navy" icon={<Shield/>} label="Worker Portal" badge="Authorised Field Staff" desc="Access assigned complaints, view issue details and submit repair evidence for administrative review." features={["View Assigned Complaints","Submit Repair Photos","Share Repair Notes","Evidence-based Closure"]} button="Enter Worker Portal" onClick={()=>onEnter("worker")}/>
      <PortalCard accent="teal" icon={<ShieldCheck/>} label="Municipal Admin Mode" badge="Authorised City Staff Only" desc="Manage city complaints, coordinate departments, review repair evidence and monitor civic trends." features={["Governance Dashboard","Complaint Management","Civic Intelligence","Resolution & Accountability"]} button="Enter Admin Mode" onClick={()=>onEnter("admin")}/>
    </div></section>
    <section className="trust-strip" id="transparency"><div className="trust-icon"><ShieldCheck/></div><div><b>Accountable governance, from report to resolution.</b><p>Every complaint has a traceable status. Repair evidence is reviewed by authorised staff before closure.</p></div><span className="trust-pill">Human-reviewed resolution</span></section>
    <footer className="landing-footer"><b>CivicPulse</b><span>© 2026 · Civic engagement prototype</span><span>Open Records　 Ethics & Oversight　 Accessibility</span></footer>
  </div>;
}
function PortalCard({accent,icon,label,badge,desc,features,button,onClick}) {return <article className={`portal-card ${accent}`}><div className="portal-card-top"><span className="portal-icon">{icon}</span><span className="access-badge">• {badge}</span></div><h3>{label}</h3><p>{desc}</p><small className="cap-label">CORE CAPABILITIES</small><div className="feature-grid">{features.map((f,i)=><span key={f}><CheckCircle2 size={13}/>{f}</span>)}</div><button className="portal-btn" onClick={onClick}>{button} <ArrowRight size={15}/></button><small className="portal-foot">{accent==="navy"?"Authorised account required":"Open resident access · demo mode"}</small></article>}
function Metric({value,label}) {return <div className="metric"><b>{value}</b><span>{label}</span></div>}
function Nav({active,icon,label,onClick}) {return <button className={`nav-item ${active?"active":""}`} onClick={onClick}>{icon}<span>{label}</span>{active&&<i/>}</button>}
function PageHeading({eyebrow,title,subtitle}) {return <div className="page-heading"><div className="eyebrow">{eyebrow}</div><h1>{title}</h1><p>{subtitle}</p></div>}
function Tab({active,onClick,children}) {return <button className={`tab ${active?"active":""}`} onClick={onClick}>{children}</button>}
function Status({value}) {let cls=value==="Resolved"?"green":value==="In Progress"?"blue":value==="Reopened"?"red":"amber";return <span className={`status ${cls}`}>{value}</span>}
function Stat({label,value,icon}) {return <div className="stat-card"><div className="stat-icon">{icon}</div><span>{label}</span><b>{value}</b><small>Current demo data</small></div>}
function TimelineItem({n,title,desc}) {return <div className="timeline-item"><span className="timeline-n">{n}</span><div><b>{title}</b><p>{desc}</p></div></div>}
function IssueDetails({issue}) {return <div className="issue-details"><div className="detail-title"><b>{issue.title}</b><Status value={issue.status}/></div><span className="muted">{issue.id} · {issue.date}</span><p>{issue.description}</p><div className="detail-meta"><span><MapPin size={14}/>{issue.location}</span><span><AlertCircle size={14}/>{issue.priority} priority</span><span><Globe2 size={14}/>{issue.ward}</span></div></div>}
function Empty({text}) {return <div className="empty-state"><ClipboardList size={26}/><p>{text}</p></div>}

createRoot(document.getElementById("root")).render(<App/>);
